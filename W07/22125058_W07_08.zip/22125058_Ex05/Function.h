void PrintPattern(int x, int old, int add);
