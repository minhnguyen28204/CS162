void Recaman(int n, int cur, int x, bool* arr);
