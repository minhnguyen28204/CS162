void OutputArray(int* arr, int n, int cur);
void OutputreversedArray(int* arr, int n, int cur);
int SumPositive(int* arr, int n, int cur);
int DistinctValues(int* arr, int* nums, int n, int cur);
