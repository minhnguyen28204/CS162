#include <iostream>
#include "Function.h"

using namespace std;

int main()
{
    int n;
    cout << "Input number: ";
    cin >> n;
    cout << sumOfDigit(n);
    return 0;
}
