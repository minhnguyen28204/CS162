int sumOfDigit(int x);
