#pragma once
#include <string>
using namespace std;

string toBinary(int x);
