#pragma once

int C(int n, int k);
