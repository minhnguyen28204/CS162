#include <string>
using namespace std;
string toHex(int x);
