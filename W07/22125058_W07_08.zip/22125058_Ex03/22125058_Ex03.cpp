#include <iostream>
#include "Function.h"

using namespace std;

int main()
{
    cout << toHex(172) << '\n';
    return 0;
}
