#include <fstream>

void EnterArray(std::ofstream &ofs, int n, int* arr);
int GetMedian(int n, int* arr);
