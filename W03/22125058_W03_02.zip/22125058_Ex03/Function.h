bool isPalindrome(char* cstr);
