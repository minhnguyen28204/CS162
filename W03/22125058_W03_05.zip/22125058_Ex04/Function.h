#pragma once
int ModeOfTheArray(int* arr, int n);
