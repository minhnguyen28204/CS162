#pragma once
void doSomething(int* x, int* y);
