#pragma once
void UserInput(double** &arr, int &n);
void Report(double** arr, int n);
