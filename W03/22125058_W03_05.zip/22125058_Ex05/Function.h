#pragma once
double Median(int* Arr, int n);
