struct Dates{
    int year, month, day;
};
void Load(Dates *&cur, int& n);
void Sort(Dates *cur, int n);
void Save(Dates *cur, int n);
