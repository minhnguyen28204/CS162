#pragma once
void DecToBin(int x, int* s, int &Size);
void BinToDec(int* s, int Size, int &x);
void DecToHex(int x, char* s, int &Size);
void HexToDec(char* s, int Size, int &x);